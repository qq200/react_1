//modul unei componente
import React, { Component } from "react";
class LikeButton extends Component {
  constructor(props) {
    super(props);
    // this.likes = 0;
    this.state = {
      likes: 0,
      enabled: true
    };
    this.click = this.click.bind(this);
  }
  click() {
    if (this.state.likes >= 2) {
      this.disable();
    }
    this.setState({
      likes: this.state.likes + 1
    });
    // alert(this.state.likes)
    // alert(this.likes);
  }
  enable() {}
  disable() {
    this.setState({
      enabled: false
    });
  }
  render() {
    return (
      <button onClick={this.click} disabled={!this.state.enabled}>
        {this.props.label}
        {this.state.likes}
      </button>
    );
  }
}

export default LikeButton;
