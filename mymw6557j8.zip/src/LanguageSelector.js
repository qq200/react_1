import React, { Component } from "react";
class LanguageSelector extends Component {
  constructor(props) {
    super(props);
    this.la = ["EN", "RO", "RU"];
  }

  render() {
    var l = this.la.map(lang => <option>{lang}</option>);
    return <select>{l}</select>;
  }
}
export default LanguageSelector;
